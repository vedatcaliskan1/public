const { getStore } = require('@netlify/blobs');

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const body = JSON.parse(event.body || '{}');
    const { password, newPassword, siteTitle, logoChar, fullname, bank, iban, desc } = body;

    const store = getStore('site-config');
    const config = await store.get('config', { type: 'json' });

    if (!config || password !== config.password) {
      return {
        statusCode: 401,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ok: false, error: 'Şifre hatalı' })
      };
    }

    const updated = {
      siteTitle: (siteTitle || '').trim() || 'Site Adı',
      logoChar: (logoChar || '').trim() || 'L',
      fullname: (fullname || '').trim(),
      bank: (bank || '').trim(),
      iban: (iban || '').trim(),
      desc: (desc || '').trim(),
      password: (newPassword && newPassword.trim().length > 0) ? newPassword.trim() : config.password
    };

    await store.setJSON('config', updated);

    const { password: _pw, ...safeConfig } = updated;
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ok: true, config: safeConfig })
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ok: false, error: 'Sunucu hatası' })
    };
  }
};
