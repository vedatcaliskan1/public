const { getStore } = require('@netlify/blobs');

const DEFAULT_CONFIG = {
  siteTitle: 'Site Adı',
  logoChar: 'L',
  fullname: 'Ad Soyad',
  bank: 'Banka Adı',
  iban: 'TR00 0000 0000 0000 0000 0000 00',
  desc: 'Ad Soyad + Sipariş No',
  password: 'admin123'
};

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const { password } = JSON.parse(event.body || '{}');
    const store = getStore('site-config');
    let config = await store.get('config', { type: 'json' });

    if (!config) {
      config = { ...DEFAULT_CONFIG };
      await store.setJSON('config', config);
    }

    if (password !== config.password) {
      return {
        statusCode: 401,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ok: false })
      };
    }

    const { password: _pw, ...safeConfig } = config;
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ok: true, config: safeConfig })
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ok: false, error: 'Sunucu hatası' })
    };
  }
};
