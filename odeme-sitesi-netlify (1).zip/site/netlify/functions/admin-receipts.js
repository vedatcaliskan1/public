const { getStore } = require('@netlify/blobs');

exports.handler = async (event) => {
  if (event.httpMethod !== 'GET') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const password = event.queryStringParameters && event.queryStringParameters.password;

    const configStore = getStore('site-config');
    const config = await configStore.get('config', { type: 'json' });

    if (!config || password !== config.password) {
      return {
        statusCode: 401,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ok: false })
      };
    }

    const store = getStore('receipts');
    const { blobs } = await store.list();

    const records = [];
    for (const b of blobs) {
      const rec = await store.get(b.key, { type: 'json' });
      if (rec) {
        rec._key = b.key;
        records.push(rec);
      }
    }

    records.sort((a, b) => new Date(b.submittedAt) - new Date(a.submittedAt));

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ok: true, records })
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ok: false, error: 'Sunucu hatası' })
    };
  }
};
