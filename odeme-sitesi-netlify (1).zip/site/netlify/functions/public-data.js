const { getStore } = require('@netlify/blobs');

const DEFAULTS = {
  siteTitle: 'Site Adı',
  logoChar: 'L',
  fullname: 'Ad Soyad',
  bank: 'Banka Adı',
  iban: 'TR00 0000 0000 0000 0000 0000 00',
  desc: 'Ad Soyad + Sipariş No'
};

exports.handler = async () => {
  try {
    const store = getStore('site-config');
    const config = await store.get('config', { type: 'json' });
    const safe = config
      ? {
          siteTitle: config.siteTitle,
          logoChar: config.logoChar,
          fullname: config.fullname,
          bank: config.bank,
          iban: config.iban,
          desc: config.desc
        }
      : DEFAULTS;

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(safe)
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'Sunucu hatası' })
    };
  }
};
