const { getStore } = require('@netlify/blobs');

const MAX_DATA_URL_LENGTH = 5.5 * 1024 * 1024; // base64 taşımalı payload sınırı

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const { filename, mimeType, dataUrl } = JSON.parse(event.body || '{}');

    if (!dataUrl || typeof dataUrl !== 'string') {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ok: false, error: 'Dosya eksik' })
      };
    }

    if (dataUrl.length > MAX_DATA_URL_LENGTH) {
      return {
        statusCode: 413,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ok: false, error: 'Dosya çok büyük' })
      };
    }

    const store = getStore('receipts');
    const id = Date.now() + '-' + Math.random().toString(36).slice(2, 8);
    const record = {
      filename: filename || 'dekont',
      mimeType: mimeType || '',
      dataUrl,
      submittedAt: new Date().toISOString()
    };

    await store.setJSON(id, record);

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ok: true })
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ok: false, error: 'Sunucu hatası' })
    };
  }
};
