# Ödeme Bilgileri Sitesi — Netlify Kurulumu

## Neden çalışmıyordu?
Önceki sürüm `window.storage` adında bir API kullanıyordu. Bu API sadece Claude'un
sohbet içi önizleme ortamında var; gerçek bir web sunucusunda (Netlify dahil)
böyle bir şey yok. Bu yüzden admin panelindeki değişiklikler hiçbir yere
kaydedilmiyordu ve index.html hep varsayılan verileri gösteriyordu.

Bu sürüm, veriyi **Netlify Functions + Netlify Blobs** ile gerçek şekilde
sunucu tarafında saklıyor. Admin panelinde yaptığın değişiklik artık gerçekten
kaydediliyor ve index.html'i ziyaret eden herkese yansıyor.

## Nasıl deploy edilir
1. Bu klasörün TAMAMINI (netlify.toml, package.json, netlify/ klasörü dahil)
   bir GitHub reposuna yükle YA DA doğrudan Netlify'ın "Deploy manually"
   (sürükle-bırak) ekranına klasörü sürükle.
2. Netlify, `netlify.toml` sayesinde fonksiyonları otomatik algılayıp
   `npm install` çalıştırıp `@netlify/blobs` paketini kuracak. Ekstra bir
   ayar veya API anahtarı girmene gerek yok — Blobs, Netlify'a deploy edilen
   sitelerde otomatik olarak çalışır.
3. Deploy bitince siteni `https://siten.netlify.app/admin.html` adresinden
   yönetebilirsin. İlk giriş şifresi: `admin123` — panelden hemen değiştir.

## Önemli notlar
- Şifre kontrolü artık sunucu tarafında yapılıyor (fonksiyonların içinde),
  yani tarayıcıdan bakan biri şifreyi kodun içinde göremez.
- Dekont dosyaları 3.5 MB'tan büyükse reddediliyor (Netlify fonksiyonlarının
  istek boyutu sınırına takılmamak için). Daha büyük dosya desteği istersen
  ayrı bir dosya depolama servisi (S3, Cloudinary vb.) gerekir, haber ver.
- Bu basit şifre tabanlı korumadır; yüksek güvenlik gerektiren bir kullanım
  için (örneğin gerçek müşteri ödemeleri yüksek hacimliyse) daha güçlü bir
  kimlik doğrulama önerebilirim.
